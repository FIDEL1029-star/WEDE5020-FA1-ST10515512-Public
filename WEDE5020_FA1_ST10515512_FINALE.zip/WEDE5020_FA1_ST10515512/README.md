# WEDE5020 FA1 - Yeezy Vault SA

**Student:** Fidel V. Netsianda  
**Student Number:** ST10515512  
**Module:** WEDE5020  
**Project:** Yeezy Vault SA - a user-friendly Yeezy fashion and footwear website

## Website pages
| Page | File | Purpose |
| --- | --- | --- |
| Home | `index.html` | Introduction, featured pairs, how the site works |
| About | `about.html` | The project and the usability principles behind it |
| Gallery | `gallery.html` | Product photos and prices, with an enlarge (lightbox) view |
| Contact | `contact.html` | Location, email and what to include in an enquiry |
| Enquiries | `enquiries.html` | Validated enquiry form |

## Folder structure
- `index.html`, `about.html`, `gallery.html`, `contact.html`, `enquiries.html`
- `css_assets/style.css` - all styling (design tokens, responsive layout, focus and print styles)
- `js_assets/script.js` - mobile menu, gallery lightbox, enquiry form validation
- `images/` - web-ready product photos, the full-resolution enhanced Yeezy 500 photo, favicon
- `_private/` - proposal material and the original, unedited source photos

## Images
All four product photos were enhanced (noise reduction, 2x upscaling, local contrast, sharpening and a small colour lift) and re-composed to a consistent 4:3 frame.
- `images/yeezy1.jpg` - grey Yeezy 500, rear view (home hero and gallery)
- `images/yeezy1-full.png` - the same photo as a 2048 px lossless master
- `images/yeezy2.jpg` - Yeezy Foam
- `images/yeezy3.jpg` - close-up of the grey Yeezy 500 heel and outsole
- `images/yeezy4.jpg` - Yeezy 500 warm stone

## Features
- Same navigation on every page, with the current page highlighted and a "Skip to main content" link
- Responsive layout: menu collapses on small screens, cards reflow to one column
- Keyboard-friendly: visible focus outlines, lightbox closes with Esc
- Gallery "Enquire" buttons pre-select the product on the enquiry form
- Enquiry form: inline error messages, character counter and on-page confirmation

## Notes
The enquiry form demonstrates front-end interaction using JavaScript; it does not send data to a live server.
