/* ==========================================================
   Yeezy Vault SA - front-end interaction
   WEDE5020 FA1 | ST10515512
   1. Mobile navigation toggle
   2. Gallery lightbox (native <dialog>)
   3. Enquiry form: validation, product pre-selection, feedback
   No data is sent to a server - this is a front-end demonstration.
   ========================================================== */

document.addEventListener("DOMContentLoaded", function () {
  "use strict";

  /* ---------- 1. Mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var menu = document.getElementById("site-menu");

  if (toggle && menu) {
    var setMenu = function (open) {
      menu.classList.toggle("open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.textContent = open ? "Close" : "Menu";
    };
    toggle.addEventListener("click", function () {
      setMenu(!menu.classList.contains("open"));
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("open")) {
        setMenu(false);
        toggle.focus();
      }
    });
  }

  /* ---------- 2. Gallery lightbox ---------- */
  var zoomButtons = document.querySelectorAll("button.zoom");

  if (zoomButtons.length && typeof HTMLDialogElement === "function") {
    var dialog = document.createElement("dialog");
    dialog.className = "lightbox";
    dialog.setAttribute("aria-label", "Enlarged product photo");
    dialog.innerHTML =
      '<button class="close" type="button" aria-label="Close enlarged photo">&times;</button>' +
      "<figure><img alt=\"\"><figcaption><span></span><a hidden target=\"_blank\" rel=\"noopener\">Open full-resolution photo</a></figcaption></figure>";
    document.body.appendChild(dialog);

    var bigImg = dialog.querySelector("img");
    var caption = dialog.querySelector("figcaption span");
    var hiresLink = dialog.querySelector("figcaption a");
    var lastTrigger = null;

    zoomButtons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        var thumb = btn.querySelector("img");
        lastTrigger = btn;
        bigImg.src = btn.dataset.full || thumb.src;
        bigImg.alt = thumb.alt;
        caption.textContent = btn.dataset.caption || thumb.alt;
        if (btn.dataset.hires) {
          hiresLink.href = btn.dataset.hires;
          hiresLink.hidden = false;
        } else {
          hiresLink.hidden = true;
        }
        dialog.showModal();
      });
    });

    dialog.querySelector(".close").addEventListener("click", function () { dialog.close(); });
    // click on the dark backdrop closes the dialog
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog) { dialog.close(); }
    });
    dialog.addEventListener("close", function () {
      if (lastTrigger) { lastTrigger.focus(); }
    });
  }

  /* ---------- 3. Enquiry form ---------- */
  var form = document.getElementById("enquiry-form");

  if (form) {
    var success = document.getElementById("enquiry-success");
    var successText = document.getElementById("success-text");
    var again = document.getElementById("send-another");
    var message = document.getElementById("message");
    var counter = document.getElementById("message-count");
    var productField = document.getElementById("product");

    // Pre-select the product when arriving from a gallery "Enquire" button
    var wanted = new URLSearchParams(window.location.search).get("product");
    if (wanted && productField) {
      Array.prototype.forEach.call(productField.options, function (opt) {
        if (opt.value === wanted) { productField.value = wanted; }
      });
    }

    var rules = {
      name: function (v) {
        if (!v.trim()) { return "Enter your full name."; }
        if (v.trim().length < 2) { return "Your name must be at least 2 characters."; }
        return "";
      },
      email: function (v) {
        if (!v.trim()) { return "Enter your email address."; }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim())) { return "Enter a valid email address, for example name@example.com."; }
        return "";
      },
      product: function (v) {
        return v ? "" : "Choose the product you are asking about.";
      },
      message: function (v) {
        if (!v.trim()) { return "Type your enquiry."; }
        if (v.trim().length < 10) { return "Please write at least 10 characters so we can help you properly."; }
        return "";
      }
    };

    var showError = function (field, text) {
      var errorEl = document.getElementById(field.id + "-error");
      if (errorEl) { errorEl.textContent = text; }
      if (text) { field.setAttribute("aria-invalid", "true"); }
      else { field.removeAttribute("aria-invalid"); }
    };

    var validateField = function (field) {
      var check = rules[field.name];
      var text = check ? check(field.value) : "";
      showError(field, text);
      return !text;
    };

    var updateCounter = function () {
      if (message && counter) {
        counter.textContent = message.value.length + " / " + message.maxLength;
      }
    };
    updateCounter();
    if (message) { message.addEventListener("input", updateCounter); }

    // Validate when a field is left, and clear errors as soon as it is fixed
    Array.prototype.forEach.call(form.elements, function (field) {
      if (!rules[field.name]) { return; }
      field.addEventListener("blur", function () { validateField(field); });
      field.addEventListener("input", function () {
        if (field.getAttribute("aria-invalid") === "true") { validateField(field); }
      });
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var firstInvalid = null;

      Array.prototype.forEach.call(form.elements, function (field) {
        if (!rules[field.name]) { return; }
        if (!validateField(field) && !firstInvalid) { firstInvalid = field; }
      });

      if (firstInvalid) { firstInvalid.focus(); return; }

      var firstName = form.elements.name.value.trim().split(/\s+/)[0];
      successText.textContent =
        "Thank you, " + firstName + ". Your enquiry about " + form.elements.product.value +
        " has been received by Yeezy Vault SA.";
      form.reset();
      updateCounter();
      form.hidden = true;
      success.hidden = false;
      success.focus();
    });

    if (again) {
      again.addEventListener("click", function () {
        success.hidden = true;
        form.hidden = false;
        form.elements.name.focus();
      });
    }
  }
});
